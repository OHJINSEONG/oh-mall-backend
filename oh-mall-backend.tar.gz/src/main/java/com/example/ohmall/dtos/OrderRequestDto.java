package com.example.ohmall.dtos;

public class OrderRequestDto {
}
