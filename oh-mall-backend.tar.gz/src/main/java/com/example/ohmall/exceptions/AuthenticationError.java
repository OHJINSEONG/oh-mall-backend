package com.example.ohmall.exceptions;

public class AuthenticationError extends RuntimeException {
}
