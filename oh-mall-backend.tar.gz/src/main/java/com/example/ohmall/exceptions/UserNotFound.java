package com.example.ohmall.exceptions;

public class UserNotFound extends RuntimeException {
}
